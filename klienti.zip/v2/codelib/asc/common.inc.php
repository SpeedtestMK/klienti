<?php
//==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>
//
// Lead Follow-Up Database v1.08
// Copyright (c) phpkobo.com ( http://www.phpkobo.com/ )
// Email : admin@phpkobo.com
// ID : LF201-108
// URL : http://www.phpkobo.com/lead_follow_up.php
//
// This software is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2 of the
// License.
//
//==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<


include( 'CNotifyFollowUp.inc.php' );

//----------------------------------------------------------------
// FileList
//----------------------------------------------------------------
require( "cls_fl_aso.inc.php" );
require( 'cls_fl_staff.inc.php' );
require( 'cls_fl_lead.inc.php' );

//----------------------------------------------------------------
// HtmlMacro
//----------------------------------------------------------------
class cls_hm_aso extends CHtmlMacro {}

//----------------------------------------------------------------
// Authorization
//----------------------------------------------------------------
class cls_auth_aso extends CAuthorization {}

//----------------------------------------------------------------
// PageSet
//----------------------------------------------------------------
class cls_ps_aso extends CVPageSet {}

//----------------------------------------------------------------
// System
//----------------------------------------------------------------
class cls_sys_aso extends CVSystem
{
	function IsAdmin()
	{
		return false;
	}

	function ShowRLog()
	{
		$b = ( $this->sys->GetUserType( UT_STAFF ) == UT_STAFF );
		return $b;
	}
}

//----------------------------------------------------------------
// END OF FILE
//----------------------------------------------------------------
?>