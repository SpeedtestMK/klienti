<?php
//==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>
//
// Lead Follow-Up Database v1.08
// Copyright (c) phpkobo.com ( http://www.phpkobo.com/ )
// Email : admin@phpkobo.com
// ID : LF201-108
// URL : http://www.phpkobo.com/lead_follow_up.php
//
// This software is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2 of the
// License.
//
//==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<


//----------------------------------------------------------------
// cls_fl_lead
//----------------------------------------------------------------
class cls_fl_lead extends cls_fl_aso
{
}

//----------------------------------------------------------------
// cls_lead_EmailConf
//----------------------------------------------------------------
class cls_lead_EmailConf extends CVEmail
{
  /**
   * Validate the value of the object
   *
   * @param object $msg
   * @return true = success, false = failure
   *
   */
	function Validate_Value( &$msg )
	{
		$v = $this->val;
		if ( !parent::Validate_Value( $msg ) ) return false;
		if ( !$this->Validate_Conf( $v ) ) return false;
		return true;
	}
	
  /**
   * Confirm email
   *
   * @param object $msg
   * @return true = success, false = failure
   *
   */
	function Validate_Conf( $v )
	{
		$obj =& $this->prt->GetChild('email');
		if ( ! ( $v == $obj->GetVal() ) )
		{
			$this->SetErrMsg( RSTR_ERR_CAN_NOT_CONFIRM, $v );
			return false;
		}

		return true;
	}
}

//----------------------------------------------------------------
// cls_staff_id
//----------------------------------------------------------------
class cls_staff_id extends CVSelection
{
	function Setup()
	{
		parent::Setup();

		$this->sel_text = $this->Populate(
			$msg,
			TBL_STAFF,
			array( "staff_id", "username" ),
			array( "active = 'Y'", "group_id <> " . GROUP_ADMIN ),
			"staff_id ASC"
		);
	}
}

//----------------------------------------------------------------
// END OF FILE
//----------------------------------------------------------------
?>