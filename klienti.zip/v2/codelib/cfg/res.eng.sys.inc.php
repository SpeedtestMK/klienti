<?php
//==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>
//
// Lead Follow-Up Database v1.08
// Copyright (c) phpkobo.com ( http://www.phpkobo.com/ )
// Email : admin@phpkobo.com
// ID : LF201-108
// URL : http://www.phpkobo.com/lead_follow_up.php
//
// This software is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2 of the
// License.
//
//==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<


//-- User Type
define( 'RSTR_UT_CAP_G', 'Гостин' );
define( 'RSTR_UT_CAP_M', 'Маркетинг Агент' );
define( 'RSTR_UT_CAP_S', 'Администратор' );

//-- Staff Type
define( 'RSTR_ADMINISTRATOR', 'Администратор' );
define( 'RSTR_GENERAL_STAFF', 'Маркетинг Агент' ); 

//-- Login Page
define( 'RSTR_LOG_IN', 'Логирање' );
define( 'RSTR_USERNAME', 'Корисничко име' );
define( 'RSTR_PASSWORD', 'Лозинка' );
define( 'RSTR_ENTER', 'ВЛЕЗ' );
define( 'RSTR_VLEZ', 'Влез');

//-- Log Off Page
define( 'RSTR_LOG_OFF', 'ИЗЛЕЗ' );

//-- Log Info
define( 'RSTR_LOG_INFO', 'ИНФО' );
define( 'RSTR_LAST_MODIFIED_AT', 'Последно модифицирано во' );
define( 'RSTR_LAST_MODIFIED_BY', 'Последно модифицирано од' );

//-- Search Section
define( 'RSTR_SEARCH', 'ПРЕТРАЖИ' );
define( 'RSTR_SEARCH_CRITERIA', 'Критериуми за претражување' );
define( 'RSTR_SEARCH_RESULT', 'Резултати од претражувањето' );

//-- Record List
define( 'RSTR_RL_NO_RECORDS_FOUND', 'Не е пронајдена таков клиент' );
define( 'RSTR_RL_SHOWING_RECORDS', 'Прикажани клиенти <b>##sel_range##</b> од <b>##total_record##</b>' );

//-- Log Section
define( 'RSTR_RLOG', 'ИНФО' );
define( 'RSTR_CREATE_DATE_TIME', 'Креирано од' );
define( 'RSTR_CREATE_USER_TYPE', 'Вид на корисник' );
define( 'RSTR_CREATE_USER_NAME', 'Креиран од' );
define( 'RSTR_EDIT_DATE_TIME', 'Последно модифицирано во' );
define( 'RSTR_EDIT_USER_TYPE', 'Модифицирано од вид на корисник' );
define( 'RSTR_EDIT_USER_NAME', 'Последно модифицирано од' );
define( 'RSTR_LAST_LOGIN_DATE_TIME', 'Последен пат логиран' );

//-- Status Bar
define( 'RSTR_BREADCRUMS_MARK', ' > ' );
define( 'RSTR_USER', 'Маркетинг Агент' );

//-- Buttons
define( 'RSTR_OK', 'OK' );
define( 'RSTR_CANCEL', 'Откажи' );
define( 'RSTR_EDIT', 'Едитирај' );
define( 'RSTR_DETAIL', 'Прегледај' );
define( 'RSTR_ADDNEW', 'Додади нов клиент' );
define( 'RSTR_SAVE', 'Зачувај' );
define( 'RSTR_DELETE', 'Избриши' );
define( 'RSTR_BACK', 'Назад' );

//-- SelRec
define( 'RSTR_SELREC_HEADER', 'Селектирај Се / Деселектирај Се' );
define( 'RSTR_SELREC_CHECKBOX', 'Селектирај / Деселектирај го клиентот' );

//-- Page Tab
define( 'RSTR_PAGETAB_FIRST', 'Прв' );
define( 'RSTR_PAGETAB_PREV', 'Претходен' );
define( 'RSTR_PAGETAB_PAGE', 'Страна #PageNo#' );
define( 'RSTR_PAGETAB_NEXT', 'Следна' );
define( 'RSTR_PAGETAB_LAST', 'Последен' );

//-- Order By
define( 'RSTR_ORDER_BY_ASC', '1 &gt;&gt; 9, А &gt;&gt Ш' );
define( 'RSTR_ORDER_BY_DESC', 'Ш &gt;&gt; A, 9 &gt;&gt; 1' );

//-- Notification
define( 'RSTR_RECORD_UPDATED', '[%s] клиентот е успешно апдејтиран.' );
define( 'RSTR_RECORD_SAVED', '[%s] клиентот е успешно зачуван.' );
define( 'RSTR_RECORD_ADDED', '[%s] клиентот е додаден.' );
define( 'RSTR_RECORD_DELETED', '[%s] е упешно избришан.' );
define( 'RSTR_RECORDS_DELETED', '[%s] се успешно избришани.' );

//-- Error Message
define( 'RSTR_ERROR', 'Грешка' );
define( 'RSTR_ERR_EMPTY', '[##c##] полето е празно.' );
define( 'RSTR_ERR_INVALID_FORMAT', '[##c##] невалиден формат ##v##' );
define( 'RSTR_ERR_TOO_SHORT', '[##c##] е премногу кратко. ##v##' );
define( 'RSTR_ERR_TOO_LONG', '[##c##] е премногу долго. ##v##' );
define( 'RSTR_ERR_TOO_SMALL', '[##c##] е премногу големо. ##v##' );
define( 'RSTR_ERR_TOO_LARGE', '[##c##] е премногу големо. ##v##' );
define( 'RSTR_ERR_INCOMPLETE_INPUT', '[##c##] не е комплетно.' );
define( 'RSTR_ERR_CAN_NOT_CONFIRM', '[##c##] неможам да го потврдам.' );
define( 'RSTR_ERR_NOT_ASCII', '[##c##] contains non-alphanumerc characters.' );
define( 'RSTR_ERR_NOT_DIGIT', '[##c##] contains non-numeric characters.' );
define( 'RSTR_ERR_DATE_NOT_EXIST', '[##c##] : Invalid date ##v## [mm/dd/yyyy]' );
define( 'RSTR_ERR_DOUBLE_SUBMIT', "This form has already been submitted." );
define( 'RSTR_ERR_WRONG_UN_PASS', 'Погрешно корисничко име или лозинка' );
define( 'RSTR_ERR_USED_USERNAME', 'The username has already been registered.' );
define( 'RSTR_ERR_CAN_NOT_DELETE_ROOT', 'Дедо Боже не се брише така лесно.' );

//-- Select
define( 'STR_SELECT_CAPTION', ' ' );
define( 'STR_SELECT_ON_TOP_FOR_SEARCH', '' );

//----------------------------------------------------------------
// END OF FILE
//----------------------------------------------------------------

?>
