<?php
//==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>
//
// Lead Follow-Up Database v1.08
// Copyright (c) phpkobo.com ( http://www.phpkobo.com/ )
// Email : admin@phpkobo.com
// ID : LF201-108
// URL : http://www.phpkobo.com/lead_follow_up.php
//
// This software is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2 of the
// License.
//
//==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<


//-- Langauge Code
define( 'LC_ENG', 'eng' );
define( 'LC_JPN', 'jpn' );

//----------------------------------------------------------------
// _LANG_FILE_
//----------------------------------------------------------------
function _LANG_FILE_( $filename )
{
	global $LANG_CODE;
	if ( !in_array( $LANG_CODE, array(
		LC_ENG,
		LC_JPN
	) ) )
	{
 		echo 'Invalid Language Code';
 		exit;
	}
	return str_replace( "##LANG_CODE##", $LANG_CODE, $filename ); 
}

//----------------------------------------------------------------
// END OF FILE
//----------------------------------------------------------------

?>