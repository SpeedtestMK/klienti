<?php

//-- Log In
define( 'RSTR_APP_MAKER', 'База на Клиенти' );

//-- About
define( 'RSTR_ABOUT', 'Информации' );
define( 'RSTR_APP_TITLE', 'База на клиенти' );
define( 'RSTR_APP_VERSION', 'V3' );
define( 'RSTR_APP_ID', 'LF201-108' );
define( 'RSTR_APP_HOMEPAGE_CAPTION',
	'Канал77' );
define( 'RSTR_APP_HOMEPAGE_URL',
	'http://www.kanal77.mk' );

//-- Staff
define( 'RSTR_STAFF', 'Маркетинг Агент' );
define( 'RSTR_STAFF_ID', 'Ред. Бр.' );
define( 'RSTR_ACTIVE', 'Активен' );
define( 'RSTR_STAFF_TYPE', 'Што да биде' );
define( 'RSTR_PASSWORD_CONF', 'Лозинка (потврдување)' );
define( 'RSTR_LEAVE_PASSWORD_BLANK',
	'(Полето со лозинка остави го празно доколку несакаш да ја променуваш лозинката.)' );
define( 'RSTR_EMAIL', 'Емаил' );
define( 'RSTR_NAME', 'Име и Презиме' );

//-- Lead
define( 'RSTR_LEAD', 'Клиент' );
define( 'RSTR_LEADS', 'Клиенти' );
define( 'RSTR_LEAD_ID', 'Ред. Бр. на Клиент' );
define( 'RSTR_COMPANY_NAME', 'Име на Клиентот' );
define( 'RSTR_BUSINESS_TYPE', 'Големина на Клиент' );
define( 'RSTR_MARKET_SEGMENT', 'Маркетинг Агент' );
define( 'RSTR_CONTACT', 'Кластер' );
define( 'RSTR_TITLE', 'Град' );
define( 'RSTR_STREET1', 'Адреса' );
define( 'RSTR_STREET2', 'Одговорно лице' );
define( 'RSTR_CITY', 'Тел на одг. лице' );
define( 'RSTR_STATE', 'Позиција на одг. лице' );
define( 'RSTR_ZIP', 'Zip' );
define( 'RSTR_COUNTRY', 'Country' );
define( 'RSTR_OFFICE_TEL', 'Телефон за контакт' );
define( 'RSTR_CELL_PHONE', 'Cell Phone' );
define( 'RSTR_FAX', 'Fax' );
define( 'RSTR_WEBSITE', 'Website' );
define( 'RSTR_COMMENT', 'Забелешка' );
define( 'RSTR_FOLLOW_UP', 'Изменет на' );
define( 'RSTR_CREATED_ON', 'Креиран од' );
define( 'RSTR_CREATED_BY', 'Креиран на' );

//----------------------------------------------------------------
// END OF FILE
//----------------------------------------------------------------

?>
