<?php

//----------------------------------------------------------------
// MySQL Database
//----------------------------------------------------------------
define( 'DB_HOSTNAME', 'localhost' );
define( 'DB_DATABASE', 'klienti' );
define( 'DB_USERNAME', 'root' );
define( 'DB_PASSWORD', '' );

?>
