
<!-- <?php echo RSTR_APP_MAKER; ?> : Верзија : <?php echo SYS_VERSION; ?> -->
<!-- <?php echo RSTR_APP_MAKER; ?> : АјДИ : <?php echo RSTR_APP_ID; ?> -->

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title><?php echo  htmlspecialchars( $hm->GetTitle( 1, ' - ' ) ); ?></title>

<?php include( 'head/tpl.sys.inc.php' ); ?>
<?php include( 'head/tpl.jquery.inc.php' ); ?>
<?php include( 'head/tpl.dmenu.inc.php' ); ?>
<?php include( 'head/tpl.data_table.inc.php' ); ?>