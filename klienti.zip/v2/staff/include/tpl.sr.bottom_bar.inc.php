
	<div class='data_table_bottom_bar'>
		<div style='float:left'>
			<?php echo $hm->Zb("stat:rs:def:msg"); ?>
		</div>
		<div style='float:right'>
			<?php echo $hm->Zb("navi:rs:def:page_tabs"); ?>
		</div>
		<div style='clear:both'></div>
	</div>