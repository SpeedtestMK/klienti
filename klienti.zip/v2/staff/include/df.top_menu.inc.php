<?php
	$spec = array(

		'lead' => array(
			'sc'=>'lead/',
			'caption'=>RSTR_LEADS,
		),

		'staff'=>array(
			'sc'=>'staff/',
			'caption'=>RSTR_STAFF,
		),

		'about'=>array(
			'sc'=>'about/',
			'caption'=>RSTR_ABOUT,
		),

		'logoff'=>array(
			'sc'=>'frame/logoff',
			'caption'=>RSTR_LOG_OFF,
		),
);

?>