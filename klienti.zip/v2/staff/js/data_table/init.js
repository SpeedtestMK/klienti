$(document).ready( function() {
	$( "table.data_table tr" ).mouseover( function() {
		$( this ).addClass( "over" );
	}).mouseout( function() {
		$( this ).removeClass( "over" );
	});
	$( "table.data_table tr:even" ).addClass( "alt" );
	$( "table.page_tabs td.page_cell" ).mouseover( function() {
		$( this ).addClass( "page_cell_over" );
	}).mouseout( function() {
		$( this ).removeClass( "page_cell_over" );
	});
	$( '#selrec_header' ).click( function() {
		$( ".selrec_checkbox" ).attr( 'checked', $(this).is( ':checked' ) );
	});
	$( '#btn_del_multi' ).click( function( event ) {
		var cnt = 0;
		$( ".selrec_checkbox" ).each( function() {
			if ( $(this).is( ':checked' ) )
			{
				cnt++;
			}
		} );

		if ( cnt == 0 )
		{
			alert( RSTR_SELECT_AT_LEAST_ONE );
		}
		else
		{
			var msg = RSTR_DELETE_CONFIRM;
			msg = msg.replace( '##cnt##', cnt );
			msg = msg.replace( '##s##', cnt > 1 ? 's' : '' );

			if ( confirm ( msg ) )
			{
				return;
			}
		}
		event.preventDefault();
	});
});