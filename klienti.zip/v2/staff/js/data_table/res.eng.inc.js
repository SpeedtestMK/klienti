var RSTR_SELECT_AT_LEAST_ONE = 'Одбери барем едно клиент кој сакаш да го избришеш.';
var RSTR_DELETE_CONFIRM = 'Дали си сигурен дека сакаш да го избришеш ##cnt## record##s##.\r\nДали навистина си сигурен?';

