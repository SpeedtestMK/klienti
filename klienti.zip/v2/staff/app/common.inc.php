<?php

require( dirname(__FILE__) . "/../../config/common.inc.php" );
require( dirname(__FILE__). "/../../codelib/sys/common.inc.php" );
require( dirname(__FILE__). "/../../codelib/asc/common.inc.php" );
require( _LANG_FILE_( "res.##LANG_CODE##.inc.php" ) );
require( 'cls_ps_base.inc.php' );
require( 'cls_ps_frame.inc.php' );
require( 'cls_ps_staff.inc.php' );
require( 'cls_ps_about.inc.php' );
require( 'cls_ps_lead.inc.php' );
require( 'cls_ps_followup.inc.php' );
require( 'cls_hm_base.inc.php' );
require( 'cls_auth_base.inc.php' );
require( 'cls_sys_base.inc.php' );

?>