<?php
define( 'RSTR_AREA_TITLE', 'Администраторски панел' );
?>