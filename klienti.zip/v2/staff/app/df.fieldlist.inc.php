<?php

$spec = array(

'staff' => array(
XA_CLASS=>'cls_fl_staff',
XA_SPEC_FILE=>'df.fl.staff.inc.php',
XA_TABLE_NAME=>TBL_STAFF,
XA_ID_NAME=>'staff_id',
XA_INIT_ORDER_BY=>'staff_id ASC',
XA_INIT_PAGE_SIZE=>20
),

'lead' => array(
XA_CLASS=>'cls_fl_lead',
XA_SPEC_FILE=>'df.fl.lead.inc.php',
XA_TABLE_NAME=>TBL_LEAD,
XA_ID_NAME=>'lead_id',
XA_INIT_ORDER_BY=>'rlog_create_date_time DESC',
XA_INIT_PAGE_SIZE=>20
),

);

?>