<?php $body_css = _LANG_FILE_( "body.##LANG_CODE##.css" ); ?>
<link href="css/<?php echo $body_css; ?>" rel="stylesheet" type="text/css"/>
<link href="css/page.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="js/default.js"></script>