<?php

class cls_ps_followup extends cls_ps_base
{
	var $fs_name = 'lead';

	function CommandProc( &$sc )
	{

		$def =& $this->GetFieldList( $this->fs_name );
		$cmd = $sc->Cmd();
		switch( $cmd )
		{
		case "notify":
			$obj =& new CNotifyFollowUp();
			$obj->Run( $def );
			$sc->status = SC_EXIT;
			break;
		default:
			$sc->RaiseError( SC_ERR_PAGE_NOT_FOUND );
			break;
		}
	}
}

?>