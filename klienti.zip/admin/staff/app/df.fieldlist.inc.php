<?php
//==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>==>>>
//
// Lead Follow-Up Database v1.08
// Copyright (c) phpkobo.com ( http://www.phpkobo.com/ )
// Email : admin@phpkobo.com
// ID : LF201-108
// URL : http://www.phpkobo.com/lead_follow_up.php
//
// This software is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2 of the
// License.
//
//==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<==<<<


$spec = array(

'staff' => array(
XA_CLASS=>'cls_fl_staff',
XA_SPEC_FILE=>'df.fl.staff.inc.php',
XA_TABLE_NAME=>TBL_STAFF,
XA_ID_NAME=>'staff_id',
XA_INIT_ORDER_BY=>'staff_id ASC',
XA_INIT_PAGE_SIZE=>20
),

'lead' => array(
XA_CLASS=>'cls_fl_lead',
XA_SPEC_FILE=>'df.fl.lead.inc.php',
XA_TABLE_NAME=>TBL_LEAD,
XA_ID_NAME=>'lead_id',
XA_INIT_ORDER_BY=>'rlog_create_date_time DESC',
XA_INIT_PAGE_SIZE=>20
),

);

?>