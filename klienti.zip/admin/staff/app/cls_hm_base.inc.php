<?php

class cls_hm_base extends cls_hm_aso
{
	function GetImagePath()
	{
		return _LANG_FILE_( "images/buttons/##LANG_CODE##/" );
	}
}

?>