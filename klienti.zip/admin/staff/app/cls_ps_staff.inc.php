<?php

class cls_ps_staff extends cls_ps_base
{
	var $ps_caption = RSTR_STAFF;
	var $fs_name = 'staff';
	var $fs_edit_inp = "(fd),(edit_inp)";
	var $fs_edit_save = "(fd),(edit_save)";
	var $fs_reg_inp = "(fd),(reg_inp)";
	var $fs_reg_save = "(fd),(reg_save)";
	var $fs_del_inp = "(fd),(del_inp)";
	function CommandProc( &$sc )
	{
		$pagesig_key = 'pagesig:' . get_class( $this );
		$def =& $this->GetFieldList( $this->fs_name );
		$cmd = $sc->Cmd();
		switch( $cmd )
		{

		case "search_init":
			$sc->SetPageID( "search_init" );
			$def->SetNS( "sp:def:" );
			$def->SetList( "(sp)" );
			$def->FromInput();
			$def->FromInitValue( 'search' );
			$def->ToState();
			$def->SetEmpty();
			$sc->SetNextSc( 'search' );
			break;

		case "search":
			if ( !$sc->CheckPrevPageID(
				array(
					'search_init',
					'search_pb',
					'search_ps',
					'search_ret'
				)
			) ) break;
			$sc->SetPageID( "search" );
			$def->SetNS( "sp:def:" );
			$def->SetList( "(sp)" );
			$def->FromState();
			$def->ClearState();
			$this->sys->PageSig->Mark( $pagesig_key );
			$b = $def->Validate( XPT_SEARCH );
			$def->ToZBuffer( XC_OF_SEARCH );
			if ( $b )
			{
				$this->SetDisplay( "def:", true );
				$qc = $def->GetQueryCond();
				$def->SetNS( "rs:def:" );
				$def->SetList( "(sr)" );
				$b_clear = isset( $this->b_search_clear_page_idx );
				$def->ToZBufferTable( "_this/search_ps", $qc, $b_clear, 'AND' );
			}
			$sc->SetDefID( $def->Get(XA_ID_NAME) );
			$this->SetPage( $sc, "search" );
			break;
		case "search_pb": 
			if ( !$sc->CheckPrevPageID(
				array(
					"search"
				)
			) ) break;
			$sc->SetPageID( "search_pb" );
			$def->SetNS( "sp:def:" );
			$def->SetList( "(sp)" );
			$def->FromInput();
			$def->ToState();
			$def->SetEmpty();
			$this->b_search_clear_page_idx = true;
			$sc->SetNextSc( 'search' );
			break;
		case "search_ps":
			if ( !$sc->CheckPrevPageID(
				array(
					"search"
				)
			) ) break;
			$sc->SetPageID( "search_ps" );
			$def->SetNS( "sp:def:" );
			$def->SetList( "(sp)" );
			$def->FromInput();
			$def->ToState();
			$def->SetEmpty();
			$sc->SetPageID( "search_ps" );
			$sc->SetNextSc( 'search' );
			break;
		case "search_pxy": 
			if ( !$sc->CheckPrevPageID(
				array(
					"search"
				)
			) ) break;
			$sc->SetPageID( "search_pxy" );
			$def->SetNS( "sp:def:" );
			$def->SetList( "(sp)" );
			$def->FromInput();
			$def->ToState();
			$def->SetEmpty();
			$sc->SetNextSc( $this->sys->GetIV('_ssc') );
			break;
		case "search_ret": 
			if ( !$sc->CheckPrevPageID(
				array(
					"edit_inp",
					"edit_done",
					"reg_inp",
					"reg_done",
					"del_multi"
				)
			) ) break;
			$sc->SetPageID( "search_ret" );
			$def->SetNS( "key:def:" );
			$def->SetList( "(key)" );
			$def->ClearState();
			$sc->SetNextSc( 'search' );
			break;
		case 'edit_init':
			if ( !$sc->CheckPrevPageID(
				array(
					"search_pxy"
				)
			) ) break;
			$sc->SetPageID( "edit_init" );
		$def->SetNS( "key:def:" );
			$def->SetList( "(key)" );
			$def->FromInput();
			$def->ToState();
			$def->SetNS( "rs:def:" );
			$def->ToState();
			if ( !$def->Validate( XPT_INPUT ) )
			{
				$sc->CriticalError( "Invalid Key" );
				break;
			}
			$qc = $def->GetQueryCond();
			$def->SetNS( "rs:def:" );
			$def->SetList( $this->fs_edit_inp . ",(rlog)" );
			if ( !$def->FromRecordSet( $qc ) )
			{
				$sc->CriticalError( "Invalid Key" );
				break;
			}
			$def->ToState();
			$sc->SetNextSc( 'edit_inp' );
			break;
		case 'edit_inp':
			if ( !$sc->CheckPrevPageID(
				array(
					"edit_init",
					"edit_done"
				)
			) ) break;
			$sc->SetPageID( "edit_inp" );
			$this->sys->ZBuffer->Set( 'page:caption_verb', RSTR_EDIT );
			$this->sys->ZBuffer->Set( 'page:verb', 'edit' );
			$def->SetNS( "rs:def:" );
			$def->SetList( "(key),(rlog)," . $this->fs_edit_inp );
			$def->FromState();
			$def->SetNS( "rs:def:" );
			$def->SetList( "(key)" );
			$def->ToZBuffer( XC_OF_DEFAULT );
			$def->SetNS( "rs:def:" );
			$def->SetList( $this->fs_edit_inp );
			$def->ToZBuffer( XC_OF_INPUT );
			$def->SetNS( "rs:def:" );
			$def->SetList( "(rlog)" );
			$def->ToZBuffer( XC_OF_DEFAULT );
			$this->SetDisplay( "def:", true );
			$this->SetPage( $sc, "detail" );
			break;

		case 'edit_done':
			if ( !$sc->CheckPrevPageID(
				array(
					"edit_inp"
				)
			) ) break;
			$sc->SetPageID( "edit_done" );
			$sc->SetNextSc( "edit_inp" );
			$def->SetNS( "key:def:" );
			$def->SetList( "(key)" );
			$def->FromState();
			if ( !$def->Validate( XPT_INPUT ) )
			{
				$sc->CriticalError( "Invalid Key" );
				break;
			}
			$qc = $def->GetQueryCond();
			$def->SetNS( 'rs:def:' );
			$def->SetList( $this->fs_edit_inp );
			$def->FromInput();
			$def->ToState();
			if ( !$this->ValidateStaffInput( $def, true, $fs_edit_save ) ) break;
			$def->SetList( $fs_edit_save );
			$id = $def->UpdateRecordSet( $qc );
			$this->ReportInfo( CMBStr::replace( "%s",
				$this->ps_caption, RSTR_RECORD_UPDATED ) );
			$sc->SetNextSc( 'search_ret' );
			break;
		case 'reg_init':
			if ( !$sc->CheckPrevPageID(
				array(
					"search_pxy"
				)
			) ) break;
			$sc->SetPageID( "reg_init" );
			$sc->SetPageID( "reg_init" );
			$this->sys->PageSig->Mark( $pagesig_key );
			$def->SetNS( "rs:def:" );
			$def->SetList( $this->fs_reg_inp );
			$def->SetEmpty();
			$def->FromInitValue( 'reg' );

			$iv = $def->GetInitValues();
			if ( $iv != null )
			{
				foreach( $iv as $key=>$val )
				{
					$obj =& $def->GetChild( $key );
					$obj->SetVal( $val );
				}
			}
			$def->ToState();
			$sc->SetNextSc( "reg_inp" );
			break;

		case 'reg_inp':
			if ( !$sc->CheckPrevPageID(
				array(
					"reg_init",
					"reg_done"
				)
			) ) break;
			$sc->SetPageID( "reg_inp" );
			$this->sys->ZBuffer->Set( 'page:caption_verb', RSTR_ADDNEW );
			$this->sys->ZBuffer->Set( 'page:verb', 'reg' );
			$def->SetNS( "rs:def:" );
			$def->SetList( $this->fs_reg_inp );
			$def->FromState();
			$def->ToZBuffer( XC_OF_INPUT );
			$this->SetDisplay( "def:", true );
			$this->SetPage( $sc, "detail" );
			break;

		case "reg_done":
			if ( !$sc->CheckPrevPageID(
				array(
					"reg_inp"
				)
			) ) break;
			$sc->SetPageID( "reg_done" );
			$sc->SetNextSc( "reg_inp" );
			if ( !$this->sys->PageSig->Check( $pagesig_key ) )
			{
				$sc->DoubleSubmitError();
				break;
			}
			$def->SetNS( 'rs:def:' );
			$def->SetList( $this->fs_reg_inp );
			$def->FromInput();
			$def->ToState();
			if ( !$def->Validate( XPT_INPUT ) ) break;
			if ( $this->CheckUsernameConflict( $def, -1 ) ) break;
			$obj =& $def->GetChild('password_new');
			$pwd = $obj->GetVal();
			$obj =& $def->GetChild('password');
			$obj->SetVal( $pwd );
			$def->SetList( $this->fs_reg_save );
			$id = $def->InsertRecordSet();
			$def->SetEmpty();
			$this->sys->PageSig->Clear( $pagesig_key );
			$this->ReportInfo( CMBStr::replace( "%s",
				$this->ps_caption, RSTR_RECORD_ADDED ) );
			$sc->SetNextSc( 'search_ret' );
			break;
		case 'del_multi':
			if ( !$sc->CheckPrevPageID(
				array(
					"search_pxy"
				)
			) ) break;
			$sc->SetPageID( "del_multi" );
			$sc->SetNextSc( 'search_ret' );
			if ( !$this->sys->PageSig->Check( $pagesig_key ) )
			{
				$sc->DoubleSubmitError();
				break;
			}
			$selrec = $this->GetSelRecArray();
			if ( count( $selrec ) == 0 )
			{
				$sc->CriticalError( "No Checkboxes are selected!" );
				break;
			}
			$key = array_search( ROOT_USER_ID, $selrec );
			if ( $key !== false )
			{
				$this->ReportError( RSTR_ERR_CAN_NOT_DELETE_ROOT );
				break;
			}
			$qc = array();
			$db =& $this->sys->DB;
			$bx = array();
			foreach( $selrec as $v )
			{
				$bx[] = "'" . $db->Sanitize($v) . "'";
			}
			$cnt = count( $bx );
			$cond = implode( ", ", $bx );
			$obj =& $def->GetPrimaryKey();
			$qc[] = "(" . $obj->GetName() . " in ( " . $cond . ") )";
			$def->DeleteRecordSet( $qc );
			$this->sys->PageSig->Clear( $pagesig_key );
			if ( $cnt <= 1 )
				$msg = RSTR_RECORD_DELETED;
			else
				$msg = RSTR_RECORDS_DELETED;
			$this->ReportInfo( CMBStr::replace( "%s",
				$this->ps_caption, $msg ) );
			break;
		default:
			$sc->RaiseError( SC_ERR_PAGE_NOT_FOUND );
			break;
		}
	}
	function ValidateStaffInput( &$def, $b_edit, &$fs_edit_save )
	{
		$obj1 =& $def->GetChild('password_new');
		$obj2 =& $def->GetChild('password_conf');
		if (( $obj1->GetVal() == '' ) && ( $obj2->GetVal() == '' ))
		{
			$obj1->Set( XA_REQUIRED, false );
			$obj2->Set( XA_REQUIRED, false );
		}
		if ( !$def->Validate( XPT_INPUT ) ) return false;
		$id = -1;
		if ( $b_edit )
		{
			$obj =& $def->GetChild( $def->Get(XA_ID_NAME) );
			$id = $obj->GetVal();
		}
		if ( $this->CheckUsernameConflict( $def, $id ) )
			return false;
		$fs_edit_save = $this->fs_edit_save;
		$obj =& $def->GetChild('password_new');
		$pwd = $obj->GetVal();
		if ( $pwd != '' )
		{
			$obj =& $def->GetChild('password');
			$obj->SetVal( $pwd );
			$fs_edit_save .= ",+password";
		}
		return true;
	}
	function CheckUsernameConflict( &$def, $id )
	{
		$p = $def->GetChild( 'username' );
		$username = $p->GetVal();
		$db =& $this->sys->DB;
		$table_name = $def->Get(XA_TABLE_NAME);
		$flist = array( "username" );
		$qc = array( "username = '". $db->Sanitize($username) . "'" );
		if ( $id != -1 ) $qc[] = $def->Get(XA_ID_NAME) . " <> {$id}";
		$sql = $db->GetSQLSelect( $table_name, $flist, $qc );
		$result = $db->Query( $sql );
		$b = ( $rs = $db->GetRowA( $result ) );
		$db->FreeResult( $result );
		if ( $b )
		{
			$p->SetErrMsg( "-" );
			$this->ReportError( RSTR_ERR_USED_USERNAME . " [" . CStr::html($username) . "]" );
		}

		return $b;
	}
}

?>