<?php
class cls_ps_about extends cls_ps_base
{

	function CommandProc( &$sc )
	{
		$pagesig_key = 'pagesig:' . get_class( $this );
		$cmd = $sc->Cmd();
		switch( $cmd )
		{
		case 'detail':
			$sc->SetPageID( "detail" );
			$this->SetPage( $sc, "detail" );
			break;
		default:
			$sc->RaiseError( SC_ERR_PAGE_NOT_FOUND );
			break;
		}
	}
}

?>