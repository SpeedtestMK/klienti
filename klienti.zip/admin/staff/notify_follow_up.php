<?php
	error_reporting( E_ALL & ~E_DEPRECATED & ~E_STRICT );
	$LANG_CODE = "eng";
	require( 'common.inc.php' );
	$sys =& CVSystem::SetupSystem( $spec_sys_base_followup );
	$sys->SetUserType( UT_GUEST );
	$sys->Run();
?>
