<?php include(INC_HTML_TAG); ?>
<?php $hm->Title( __FILE__, RSTR_APP_TITLE, RSTR_LEADS, RSTR_SEARCH ); ?>

<head><?php include(INC_HTML_HEADER); ?></head>

<body>

<!-- [BEGIN] Container -->
<div id="container">

<?php include(INC_BODY_HEADER); ?>

<!-- [BEGIN] Main Form -->
<div id="main_div">

<?php include(INC_FORM_BEGIN); ?>

<?php include(INC_BODY_INFO); ?>

	<!-- [BEGIN] Search Criteria -->
	<?php echo $hm->SectBegin( RSTR_SEARCH_CRITERIA ); ?>

	<div style='overflow:auto;'>
	<table width='100%'>

	<tr>
		<td align="right"><?php echo RSTR_COMPANY_NAME; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:company_name' ); ?></td>
		<?php if ( $sys->IsAdmin() ) { ?>
			<td align="right"><?php echo RSTR_CREATED_BY; ?> : </td>
			<td align="left"><?php echo $hm->Zb( 'sp:def:staff_id' ); ?></td>
		<?php } else { ?>

			<td align="right">&nbsp;</td>
			<td align="left">&nbsp;</td>
		<?php } ?>
	</tr>

	<tr>
		<td align="right"><?php echo RSTR_BUSINESS_TYPE; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:business_type' ); ?></td>
		<td align="right"><?php echo RSTR_ACTIVE; ?>:</td>
		<td align="left"><?php echo $hm->Zb('sp:def:active'); ?></td>
		<td align="right"><?php echo RSTR_MARKET_SEGMENT; ?> : </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:market_segment' ); ?></td>
		<td align="right">&nbsp;</td>
		<td align="left">&nbsp;</td>
	</tr>

	<tr>
		<td align="right"><?php echo RSTR_CONTACT; ?>: </td>
		<td align="left"><?php echo $hm->Zb( 'sp:def:contact' ); ?></td>
		<td align="right"><?php echo RSTR_TITLE; ?>:</td>
		<td align="left"><?php echo $hm->Zb('sp:def:title'); ?></td>
		<td align="right">&nbsp;</td>
		<td align="right"><?php echo $hm->Button( array( '<>'=>'</>', 'name'=>"_sc=_this/search_pb&", 'src'=>'search', 'value'=>RSTR_SEARCH ) ); ?></td>
	</tr>

	</table>
	</div>

	<?php echo $hm->SectEnd(); ?>
	<!-- [END] Search Criteria-->

	<!-- [BEGIN] Search Result -->
	<?php if ( $hm->Zb("def:display?") ) { ?>

	<?php echo $hm->SectBegin( RSTR_SEARCH_RESULT ); ?>

<!-- TUKA TREBA DA NE STOI KOPCETO ADD NITU DELETE SAMO ZA STAFO -->

	<?php include(INC_SR_TOP_BAR); ?>


	<div style='overflow:auto;'>
	<table class='data_table'>

		<tr class='data_table_caption'>
			<th><?php include(INC_SR_SELREC_HEADER); ?></th>
			<th><?php include(INC_SR_EDIT_BTN_HEADER); ?></th>
			<th><?php echo RSTR_ACTIVE; ?></th>
			
			<?php if ( $sys->IsAdmin() ) { ?>
			<th nowrap='true'><?php echo RSTR_CREATED_BY; ?></th>
			<?php } ?>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:company_name'); ?> <?php echo RSTR_COMPANY_NAME; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:market_segment'); ?> <?php echo RSTR_MARKET_SEGMENT; ?></th>
			<th nowrap='true'><?php echo $hm->Zb('ob:rs:def:title'); ?> Град</th>
			<th nowrap='true'>Преостанато време</th>
			<th nowarp='true'>Одземена Фирма</th>
		</tr>

		<?php while( $hm->zb('@rs:def:begin_table') ) { ?>
		<tr>
			<?php include(INC_SR_ID_PARAM); ?>
			<?php include(INC_SR_SELREC); ?>
			<?php include(INC_SR_EDIT_BTN); ?>
			<td style='text-align:center;'><?php echo $hm->Zb('rs:def:active'); ?></td>
			
			<?php if ( $sys->IsAdmin() ) { ?>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:rlog_create_user_name'); ?></td>
			<?php } ?>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:company_name'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:market_segment'); ?></td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:title'); ?></td>
			<td style='text-align:left;'>Преостануваат уште (<?php echo $hm->Zb('rs:def:vreme'); ?>) дена</td>
			<td style='text-align:left;'><?php echo $hm->Zb('rs:def:odzemena_firma'); ?></td>
		</tr>
		<?php } ?>

	</table>
	</div>

	<?php include(INC_SR_BOTTOM_BAR); ?>

	<?php echo $hm->SectEnd(); ?>

	<?php } ?>
	<!-- [END] Search Result -->

	<?php echo $hm->SectEndMarker(); ?>

<?php include(INC_FORM_END); ?>

</div>
<!-- [END] Main Form -->

<?php include(INC_BODY_FOOTER); ?>

</div>
<!-- [END] Container -->

</body>
</html>

<?php include(INC_HTML_END); ?>
