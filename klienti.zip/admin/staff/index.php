<?php
	error_reporting( E_ALL & ~E_DEPRECATED & ~E_STRICT );
	require( 'common.inc.php' );
	$sys =& CVSystem::SetupSystem( $spec_sys_base );
	$sys->SetUserType( UT_STAFF );
	$sys->Run();
?>
