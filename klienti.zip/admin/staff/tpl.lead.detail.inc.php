<?php include(INC_HTML_TAG); ?>
<?php $hm->Title( __FILE__, RSTR_APP_TITLE, RSTR_LEAD, $hm->Zb( 'page:caption_verb' ) ); ?>
<?php include(INC_DETAIL_VERB); ?>

<head><?php include(INC_HTML_HEADER); ?>
<?php include('head/tpl.head.datepicker.inc.php'); ?>
</head>

<body>

<!-- [BEGIN] Container -->
<div id="container">

<?php include(INC_BODY_HEADER); ?>

<!-- [BEGIN] Main Form -->
<div id="main_div">

<?php include(INC_FORM_BEGIN); ?>

<?php include(INC_BODY_INFO); ?>

	<?php if ( $hm->Zb("def:display?") ) { ?>

	<!-- [BEGIN] basic_info -->
	<?php echo $hm->SectBegin( $hm->Zb( 'page:caption_verb' ) . " [" . RSTR_LEAD ."]" ); ?>

	<div style='overflow:auto;'>
	<table width='100%' border='0' cellpadding='3' cellspacing='1'>

	<?php if ( $b_edit || $b_del ) { ?>
	<tr>
		<td class='column_caption'><span class="required"></span> <?php echo RSTR_LEAD_ID; ?> : </td>
		<td class='column_value'><?php echo $hm->Zb('rs:def:lead_id'); ?></td>
	</tr>
	<?php } ?>

	<?php if ( $b_edit || $b_del ) { ?>
	<tr>
		<td class='column_caption'>
			<?php if ( $b_reg || $b_edit ) { ?><span class="required"></span><?php } ?>
			<?php echo RSTR_CREATED_ON; ?> :
		</td>
		<td class='column_value'><?php echo $hm->Zb('rs:def:rlog_create_date_time'); ?>
		</td>
	</tr>
	<?php } ?>
	
	<?php if ( $b_edit || $b_del ) { ?>
	<tr>
		<td class='column_caption'>
			<?php if ( $b_reg || $b_edit ) { ?><span class="required"></span><?php } ?>
			<?php echo RSTR_EDIT_ON; ?> :
		</td>
		<td class='column_value'><?php echo $hm->Zb('rs:def:rlog_edit_date_time'); ?>
		</td>
	</tr>
	<?php } ?>

	<?php if ( $sys->IsAdmin() ) { ?>
	<?php if ( $b_edit || $b_del ) { ?>
	<tr>
		<td class='column_caption'>
			<?php if ( $b_reg || $b_edit ) { ?><span class="required"></span><?php } ?>
			<?php echo RSTR_CREATED_BY; ?> :
		</td>
		<td class='column_value'><?php echo $hm->Zb('rs:def:rlog_create_user_name'); ?>
		</td>
	</tr>
	<?php } ?>
	<?php } ?>

	<tr>
		<td class='column_caption'>
			<?php if ( $b_reg || $b_edit ) { ?>
			<span class="required">*</span>
			<?php } ?>
			<?php echo RSTR_ACTIVE; ?> :
		</td>
		<td class='column_value'>
			<?php if ( $b_reg || $b_edit ) { ?>
				<?php echo $hm->Zb('rs:def:active_Y'); ?>Да&nbsp;&nbsp;&nbsp;
				<?php echo $hm->Zb('rs:def:active_N'); ?>Не
			<?php } ?>
			<?php if ( $b_del ) { ?>
				<?php echo $hm->Zb('rs:def:active'); ?>
			<?php } ?>
		</td>
	</tr>

	<tr>
		<td class='column_caption'>
			<?php if ( $b_reg || $b_edit ) { ?><span class="required"></span><?php } ?>
			<?php echo RSTR_COMPANY_NAME; ?> :
		</td>
		<td class='column_value'><?php echo $hm->Zb('rs:def:company_name'); ?>
		</td>
	</tr>

	<tr>
		<td class='column_caption'>
			<?php if ( $b_reg || $b_edit ) { ?><span class="required"></span><?php } ?>
			<?php echo RSTR_BUSINESS_TYPE; ?> :
		</td>
		<td class='column_value'><?php echo $hm->Zb('rs:def:business_type'); ?>
		</td>
	</tr>

	<tr>
		<td class='column_caption'>
			<?php if ( $b_reg || $b_edit ) { ?><span class="required"></span><?php } ?>
			<?php echo RSTR_MARKET_SEGMENT; ?> :
		</td>

		<td class='column_value'><?php echo $hm->zb('rs:def:market_segment'); ?><br>
    <strong>Активни маркетинг агенти:</strong> <br>Цветанка Павлова<br>Снежана Мицевска<br>Станислава Мицова<br>Виолета Стојкоска<br>Зоран Ѓурков<br>Нема Маркетинг Агент<br>Виктор Гаврилов<br>Слободанка Блажевска<br>Горан Гаврилов<br>Емилија Давчева
		</td>		
	</tr>

	<tr>
		<td class='column_caption'>
			<?php if ( $b_reg || $b_edit ) { ?><span class="required"></span><?php } ?>
			<?php echo RSTR_CONTACT; ?> :
		</td>
		<td class='column_value'><?php echo $hm->Zb('rs:def:contact'); ?>
		</td>
	</tr>

	<tr>
		<td class='column_caption'>
			<?php if ( $b_reg || $b_edit ) { ?><span class="required"></span><?php } ?>
			<?php echo RSTR_FOLLOW_UP; ?> :
		</td>
		<td class='column_value'><?php echo $hm->Zb('rs:def:follow_up',
			( $b_edit || $b_reg ? ZB_ATTR : null ), array('id'=>'follow_up')); ?>
		</td>
	</tr>

	<tr>
		<td class='column_caption'>
			<?php if ( $b_reg || $b_edit ) { ?><span class="required"></span><?php } ?>
			<?php echo RSTR_TITLE; ?> :
		</td>
		<td class='column_value'><?php echo $hm->Zb('rs:def:title'); ?>
		</td>
	</tr>

	<tr>
		<td class='column_caption'>
			<?php if ( $b_reg || $b_edit ) { ?><span class="required"></span><?php } ?>
			<?php echo RSTR_STREET1; ?> :
		</td>
		<td class='column_value'><?php echo $hm->Zb('rs:def:street1'); ?>
		</td>
	</tr>

	<tr>
		<td class='column_caption'>
			<?php if ( $b_reg || $b_edit ) { ?><span class="required"></span><?php } ?>
			<?php echo RSTR_STREET2; ?> :
		</td>
		<td class='column_value'><?php echo $hm->Zb('rs:def:street2'); ?>
		</td>
	</tr>

	<tr>
		<td class='column_caption'>
			<?php if ( $b_reg || $b_edit ) { ?><span class="required"></span><?php } ?>
			<?php echo RSTR_CITY; ?> :
		</td>
		<td class='column_value'><?php echo $hm->Zb('rs:def:city'); ?>
		</td>
	</tr>

	<tr>
		<td class='column_caption'>
			<?php if ( $b_reg || $b_edit ) { ?><span class="required"></span><?php } ?>
			<?php echo RSTR_STATE; ?> :
		</td>
		<td class='column_value'><?php echo $hm->Zb('rs:def:state'); ?>
		</td>
	</tr>

	<tr>
		<td class='column_caption'>
			<?php if ( $b_reg || $b_edit ) { ?><span class="required"></span><?php } ?>
			<?php echo RSTR_OFFICE_TEL; ?> :
		</td>
		<td class='column_value'><?php echo $hm->Zb('rs:def:office_tel'); ?>
		</td>
	</tr>

	<tr>
		<td class='column_caption'>
			<?php if ( $b_reg || $b_edit ) { ?><span class="required"></span><?php } ?>
			<?php echo RSTR_COMMENT; ?> : </td>
		<td class='column_value'><?php echo $hm->Zb('rs:def:comment'); ?>
		</td>
	</tr>

	</table>
	</div>

	<?php echo $hm->SectEnd(); ?>
	<!-- [END] basic_info -->

	<?php include(INC_DETAIL_LOG_INFO); ?>

	<?php echo $hm->SectEndMarker(); ?>

	<?php include(INC_DETAIL_BUTTONS); ?>

	<?php } ?>

<?php include(INC_FORM_END); ?>

</div>
<!-- [END] Main Form -->

<?php include(INC_BODY_FOOTER); ?>

</div>
<!-- [END] Container -->

</body>
</html>

<?php include(INC_HTML_END); ?>