			<td style='text-align:center;' valign='middle'><?php
				echo $hm->Button( array( 
 					'<>'=>'<image/>',
 					'name'=>"_sc=_this/search_pxy&_ssc=edit_init&{$param}&",
					'src'=>'icon_edit.gif',
 					'value'=>RSTR_EDIT,
 					'class'=>'btn_icon_edit'
 				) ); ?></td>
