<?php

require( 'app/common.inc.php' );
require( 'include/common.inc.php' );

?>