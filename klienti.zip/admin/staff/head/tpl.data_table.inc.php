<!-- [BEGIN] data_table -->
<?php $res_js = _LANG_FILE_( "res.##LANG_CODE##.inc.js" ); ?>
<link href="js/data_table/css/data_table.css" rel="stylesheet" type="text/css"/>
<link href="http://d2v52k3cl9vedd.cloudfront.net/basscss/7.0.4/basscss.min.css" rel="stylesheet">
<script type="text/javascript" src="js/data_table/<?php echo $res_js; ?>"></script>
<script type="text/javascript" src="js/data_table/init.js"></script>
<!-- [END] data_table -->

