<script type="text/javascript" src="js/jquery/jquery-ui-1.8.2.custom.min.js"></script>
<link rel="stylesheet" href="js/jquery/css/redmond/jquery-ui-1.8.2.custom.css" type="text/css" media="screen" title="Flora (Default)" />

<script  type="text/javascript">
$(document).ready(function(){
	$( '#follow_up' ).datepicker( { 
		dateFormat: 'yy-mm-dd',
		showOn: 'both',
		buttonImage: 'js/jquery/images/calendar.gif',
		buttonImageOnly: true,
		yearRange:'-0:+10'
	}).addClass( 'embed' );
});
</script>

<style type="text/css">

.input_datepick {
	width:90px;
	height:16px;
}

</style>
