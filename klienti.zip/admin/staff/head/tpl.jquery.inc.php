<!-- [BEGIN] jQuery -->
<script type="text/javascript" src="js/jquery/jquery-1.4.2.min.js"></script>
<!-- [END] jQuery -->

