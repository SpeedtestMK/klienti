<?php

class cls_auth_aso extends CAuthorization
{
}

?>