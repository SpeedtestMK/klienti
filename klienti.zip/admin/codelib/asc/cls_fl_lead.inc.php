<?php

class cls_fl_lead extends cls_fl_aso
{
}

class cls_lead_EmailConf extends CVEmail
{
	function Validate_Value( &$msg )
	{
		$v = $this->val;
		if ( !parent::Validate_Value( $msg ) ) return false;
		if ( !$this->Validate_Conf( $v ) ) return false;
		return true;
	}
	
	function Validate_Conf( $v )
	{
		$obj =& $this->prt->GetChild('email');
		if ( ! ( $v == $obj->GetVal() ) )
		{
			$this->SetErrMsg( RSTR_ERR_CAN_NOT_CONFIRM, $v );
			return false;
		}

		return true;
	}
}

class cls_staff_id extends CVSelection
{
	function Setup()
	{
		parent::Setup();

		$this->sel_text = $this->Populate(
			$msg,
			TBL_STAFF,
			array( "staff_id", "username" ),
			array( "active = 'Y'", "group_id <> " . GROUP_ADMIN ),
			"staff_id ASC"
		);
	}
}

?>