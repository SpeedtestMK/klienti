<?php
include( 'CNotifyFollowUp.inc.php' );
require( "cls_fl_aso.inc.php" );
require( 'cls_fl_staff.inc.php' );
require( 'cls_fl_lead.inc.php' );

class cls_hm_aso extends CHtmlMacro {}

class cls_auth_aso extends CAuthorization {}

class cls_ps_aso extends CVPageSet {}

class cls_sys_aso extends CVSystem
{
	function IsAdmin()
	{
		return false;
	}

	function ShowRLog()
	{
		$b = ( $this->sys->GetUserType( UT_STAFF ) == UT_STAFF );
		return $b;
	}
}

?>