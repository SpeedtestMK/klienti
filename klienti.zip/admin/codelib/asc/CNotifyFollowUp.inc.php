<?php

class CNotifyFollowUp
{
	function SendNotifyEmail( &$def, &$rs, $email_address )
	{
		$obj =& $def->GetChild( 'lead_id' );
		$obj->SetVal( $rs['lead_id'] );
		$def->SetList( "(key)" );
		$qc = $def->GetQueryCond();

		$def->SetList( "(fd),(rlog)" );
		$def->SetNS( "rs:def:" );
		if ( !$def->FromRecordSet( $qc ) )
		{
			return false;
		}
		$def->ToZBuffer( XC_OF_DEFAULT );

		global $sys;
		$path = PATH_CONFIG . "config.email.noify_follow_up.php";

		$email =& new CEmail();
		$email->OpenConfig( $path );
		$email->SetParam( "To", array( array( $email_address ) ) );

		$Body = $email->GetParam( 'Body' );
		if ( !is_null( $Body ) )
		{
			foreach( $def->clist as $key => $val )
			{
				$v = $sys->ZBuffer->Get( "rs:def:" . $key . "=" );
				$Body = str_replace( "##" . $key . "##", $v, $Body );
			}
			$email->SetParam( 'Body', $Body );
		}

		$Html = $email->GetParam( 'Html' );
		if ( !is_null( $Html ) )
		{
			foreach( $def->clist as $key => $val )
			{
				$v = $sys->ZBuffer->Get( "rs:def:" . $key );
				$Html = str_replace( "##" . $key . "##", $v, $Html );
			}
			$email->SetParam( 'Html', $Html );
		}

		$b = $email->Send();

		$msg = "EMAIL ERROR : ";
		if ( $b )
			$msg .= "NONE";
		else
			$msg .= $email->GetErrMsg();

		$subject = ( $b ? "Email Sent" : "Email Error" );
		$subject .= ":" . $email_address;
		$body = $msg;
		$body .= "\r\n\r\n";
		$body .= $email->GetSmtpLog();
		$obj =& new CGenLog();
		$obj->Send( $sys, "NotifyFollowUp", $subject, $body );

		return $b;
	}

	function GetEmailAddr( &$db, $user_id )
	{
		$email = null;

		$sql = "SELECT * FROM " . TBL_STAFF . " WHERE (" . 
			"( active = 'Y' ) AND " . 
			"( staff_id = {$user_id} )" .
			") " .
			"LIMIT 1";

		$result = $db->Query( $sql );
		if ( $rs = $db->GetRowA( $result ) )
		{
			$email = $rs['email'];
		}
		$db->FreeResult( $result );

		return $email;
	}

	function Run( &$def )
	{
		global $sys;
		$mail_sent = 0;
		$mail_error = 0;

		$start_date = date('Y-m-d');
		$ts = time( $start_date );
		$te = CUtil::DateAdd( $ts, 0, 0, 1, 0, 0, 0 );
		$end_date = date('Y-m-d', $te);

		$db =& $sys->DB;
		$sql = "SELECT * FROM " . TBL_LEAD . " WHERE (" .
			"( active = 'Y' ) AND " . 
			"( '{$start_date}' <= follow_up ) AND " .
			"( follow_up < '{$end_date}' )" .
			") " .
			"ORDER BY lead_id ASC";

		$result = $db->Query( $sql );
		while ( $rs = $db->GetRowA( $result ) )
		{
			$user_id = $rs['rlog_create_user_id'];
			$email = $this->GetEmailAddr( $db, $user_id );

			if ( $email != null )
			{
				if ( $this->SendNotifyEmail( $def, $rs, $email ) )
					$mail_sent++;
				else
					$mail_error++;
			}
		}
		$db->FreeResult( $result );

		$s = sprintf( "mail_sent=%d, mail_error=%d", $mail_sent, $mail_error );
		echo $s;
	}
}

?>
