<?php
//-- Корисници
define( 'UT_GUEST', 'G' );
define( 'UT_MEMBER', 'M' );
define( 'UT_STAFF', 'S' );

//-- GospoD
define( 'ROOT_USER_ID', 1001 );

//-- Групи
define( 'GROUP_ADMIN', 1001 );
define( 'GROUP_STAFF', 1002 );

//-- стринг
define( 'CRLF', "\r\n" );

//-- големина на поле за пребарување
define( 'SB_Size', 30 );

//-- за SQL Injecton заштита
define( 'STR_DEF_SELECT_CAPTION', '*' );

?>