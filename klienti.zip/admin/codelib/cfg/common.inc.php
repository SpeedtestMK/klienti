<?php

require( 'config.debug.inc.php' );
require( 'config.options.inc.php' );
require( 'config.system.inc.php' );
require( 'config.table_name.inc.php' );
require( _LANG_FILE_( "res.##LANG_CODE##.sys.inc.php" ) );
require( _LANG_FILE_( "res.##LANG_CODE##.app.inc.php" ) );

?>