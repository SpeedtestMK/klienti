<?php

define( 'DEBUG_SKIP_DOUBLE_SUBMIT_CHECK', false );

define( 'DEBUG_WRITE_TO_CONSOLE', false );
define( 'DEBUG_PATH_CONSOLE_OUT', dirname(__FILE__) . "/../../" );

define( 'DEBUG_DISPLAY_SMTP_LOG', false );

define( 'DEBUG_TRACE_MSG_LOOP', false );

?>