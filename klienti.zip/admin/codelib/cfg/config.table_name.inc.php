<?php

define( 'TBL_PREFIX', 'tbl_' );
define( 'TBL_GENLOG', TBL_PREFIX . 'genlog' );
define( 'TBL_STAFF', TBL_PREFIX . 'staff' );
define( 'TBL_LEAD', TBL_PREFIX . 'lead' );

?>