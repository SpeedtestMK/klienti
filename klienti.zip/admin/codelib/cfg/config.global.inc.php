<?php
$LANG_CODE = "eng";
?>