<?php

define( 'SYS_INTERNAL_ENCODING', 'utf8' );
define( 'SYS_OUTPUT_ENCODING', 'utf8' );
define( 'SYS_KEEP_LOG_PERIOD', 90 );
define( 'DUMP_DELETED_RECORD', false );
define( 'MULTI_LANG_TEMPLATE', false );
define( 'SAVE_AS_HTML_PAGE', true );
define( 'INIT_FORM_ARRAY_PREFIX', 'init_values_for_' );

?>