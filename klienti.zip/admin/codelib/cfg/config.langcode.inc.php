<?php

define( 'LC_ENG', 'eng' );
define( 'LC_JPN', 'jpn' );

function _LANG_FILE_( $filename )
{
	global $LANG_CODE;
	if ( !in_array( $LANG_CODE, array(
		LC_ENG,
		LC_JPN
	) ) )
	{
 		echo 'Невалиден код на јазик';
 		exit;
	}
	return str_replace( "##LANG_CODE##", $LANG_CODE, $filename ); 
}

?>