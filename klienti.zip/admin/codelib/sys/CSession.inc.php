<?php

class CSession extends CObject
{
	function Setup()
	{
		@session_cache_limiter('none');
		@session_start();
	}
}

//----------------------------------------------------------------
// END OF FILE
//----------------------------------------------------------------
?>