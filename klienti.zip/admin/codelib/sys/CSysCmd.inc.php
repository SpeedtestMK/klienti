<?php

define( 'STR_SYSCMD_KEY', '_sc');
define( 'STR_SC_INTERNAL_SEPA', '/' );
define( 'STR_THIS', '_this' );
define( 'STR_DEFAULT', '_def' );
define( 'STR_THIS_PAGESET', '_this_ps' );
define( 'STR_THIS_COMMAND', '_this_cmd' );
define( 'STR_PAGE_ID', '_pid' );
define( 'STR_SKIP_TPL', '_!_SKIP_TPL_!_' );
define( 'SC_NONE', 0 );
define( 'SC_OK', 1 );
define( 'SC_EXIT', 2 );
define( 'SC_ERR_CRITICAL_ERROR', -1 );
define( 'SC_ERR_PAGE_NOT_FOUND', -2 );
define( 'SC_ERR_UNAUTHORIZED', -3 );
define( 'SC_ERR_CIRCULATION_SEQ', -4 );
define( 'SC_ERR_WRONG_PAGE_SEQ', -5 );

class CSysCmd
{
	function CSysCmd( &$sys )
	{
		$this->sys =& $sys;
		$this->ps_obj = null;
		$this->status = SC_NONE;
		$this->counter = 0;
		$this->cmd = '';
		$this->ps_name = '';
		$this->SetNextSc( $sys->GetIV( STR_SYSCMD_KEY ) );
		$this->history = array();
	}

	function Cmd()
	{
		return $this->cmd;
	}

	function Ps()
	{
		return $this->ps_name;
	}

	function GetDefID()
	{
		return $this->def_id;
	}

	function SetDefID( $def_id )
	{
		$this->def_id = $def_id;
	}

	function SetNextSc( $syscmd )
	{
		if ( strpos( $syscmd, STR_SC_INTERNAL_SEPA ) !== false )
		{
			$ax = split( STR_SC_INTERNAL_SEPA, $syscmd );
			if ( count($ax) == 2 )
			{
				$this->SetNextPageSet( $ax[0] );
				$this->next_command = $ax[1];
			}
			else
			{
				if ( DEBUG_WRITE_TO_CONSOLE )
				{
					$s = "Invalid Format in SC : " . $syscmd;
					CConsole::Write( get_class($this) . '/system_error', $s );
				}
			}
		}
		else
		{
			if ( $this->ps_obj != null )
				$this->SetNextPageSet( $this->ps_obj->name );
			else
				$this->SetNextPageSet( '' );
			$this->next_command = $syscmd;
		}
	}

	function SetNextPageSet( $ps_name )
	{
		if ( $ps_name == STR_THIS )
			$this->next_ps_name = $this->sys->State->Get( STR_THIS_PAGESET );
		else if (( $ps_name == '' ) || ( $ps_name == STR_DEFAULT ))
			$this->next_ps_name = $this->sys->Get( XA_DEFAULT_PAGESET );
		else
			$this->next_ps_name = $ps_name;
	}

	function GetCurrScRec()
	{
		$cnt = count( $this->history );
		if ( $cnt == 0 )
			return null;
		else
			return $this->history[ $cnt-1 ];
	}
	
	function FindScInHistory( $ps_name, $cmd )
	{
		foreach( $this->history as $v )
		{
			if (( $v['ps_name'] == $ps_name ) && ( $v['cmd'] == $cmd ))
				return true;
		}
		return false;
	}

	function CheckCounter()
	{
		$this->counter++;
		if ( $this->counter > 100 )
		{
			$this->sys->SystemError( get_class($this) . '/CheckCounter', "Премногу лупови." );
		}
	}
	
	function GetNextPageSet( &$ps_name )
	{
		$this->CheckCounter();
		if ( $this->status != SC_NONE ) return false;
		$ps_name = $this->next_ps_name;
		return true;
	}

	function GetNextCommand( &$ps_obj )
	{
		$this->CheckCounter();
		if ( $this->status != SC_NONE )
			return false;
		$sc_rec = $this->GetCurrScRec();

		if (( $sc_rec != null ) && ( $ps_obj->name != $this->next_ps_name ))
			return false;
		$this->ps_obj =& $ps_obj; 
		$this->ps_name = $ps_obj->name;

		$cmd = $this->next_command;
		if (( $cmd == '' ) || ( $cmd == STR_DEFAULT ))
			$this->cmd = $ps_obj->Get(XA_DEFAULT_COMMAND);
		else
			$this->cmd = $cmd;
		if ( $this->FindScInHistory( $this->ps_name, $this->cmd ) )
		{
			$this->RaiseError( SC_ERR_CIRCULATION_SEQ );
			return false;
		}
		$this->history[] = array(
			'ps_name'=>$this->ps_name,
			'ps_obj'=>&$this->ps_obj,
			'cmd'=>$this->cmd );

		return true;
	}

	function SetPage( $path_template )
	{
		$sc_rec = $this->GetCurrScRec();
		if ( $sc_rec == null )
			$this->ps_obj = null;
		else
			$this->ps_obj =& $sc_rec['ps_obj'];
		$this->path_template = $path_template;
		$this->status = SC_OK;
	}

	function SetPageID( $page_id )
	{
		$this->sys->State->Set( STR_PAGE_ID, $page_id );
	}

	function GetPrevPageID()
	{
		return $this->sys->State->Get( STR_PAGE_ID );
	}

	function CheckPrevPageID( $prev_page_id_array )
	{
		if ( !in_array( $this->GetPrevPageID(), $prev_page_id_array ) )
		{
			$this->RaiseError( SC_ERR_WRONG_PAGE_SEQ );
			return false;
		}
		else
			return true;
	}

	function OutputPage( $path_template )
	{
		$this->sys->SysInfo->Commit();
		$ienc = SYS_INTERNAL_ENCODING;
		$oenc = SYS_OUTPUT_ENCODING;
		$b_change_char_encoding = ( $ienc != $oenc );
		$b_print_to_html = SAVE_AS_HTML_PAGE;
		if ( $b_change_char_encoding || $b_print_to_html )
		{
			ob_start();
		}
		global $hm;
		$hm =& $this->sys->HtmlMacro;
		if ( isset( $this->def_id ) ) $hm->SetDefID( $this->GetDefID() );
		$sys =& $this->sys;
		$b_skip_template = ( $path_template == STR_SKIP_TPL );
		if ( !$b_skip_template )
		{
			if ( !file_exists( $path_template ) )
			{
				$this->sys->SystemError( get_class($this) . '/Output', "темплејтот ( {$path_template} ) не постои." );
			}
		}

		if ( $this->ps_obj == null )
		{
			$this->sys->CurrentPageSet = null;
			$this->sys->State->Set( STR_THIS_PAGESET, 'null' );
		}
		else
		{
			$this->sys->CurrentPageSet =& $this->ps_obj;
			$this->sys->State->Set( STR_THIS_PAGESET, $this->ps_obj->name );
		}

		if ( !$b_skip_template)
		{
			require( $path_template);
		}

		if ( $b_change_char_encoding || $b_print_to_html )
		{
			$txt = ob_get_contents();
			ob_end_clean(); 
			if ( $b_change_char_encoding )
				echo mb_convert_encoding( $txt, $oenc, $ienc );
			else
				echo $txt;

			if ( $b_print_to_html )
			{
				if (( $this->Ps() != '' ) || ( $this->Cmd() != '' ))
					CToHtml::Save( $this->Ps(), $this->Cmd(), $txt );
			}
		}
	}

	function OutputCriticalErrorPage( $msg )
	{
		$this->sys->Error->ShowError( "Critical Error : " . $msg );
	}

	function RaiseError( $status )
	{
		$this->status = $status;
	}

	function CriticalError( $err_msg )
	{
		$this->critical_err_msg = $err_msg;
		$this->RaiseError( SC_ERR_CRITICAL_ERROR );
	}
	
	function DoubleSubmitError()
	{
		$this->sys->Error->ShowError( RSTR_ERR_DOUBLE_SUBMIT );
	}

	function GetNextSc()
	{
		$s = ( isset( $this->next_ps_name ) ? $this->next_ps_name : "?" );
		$s .= STR_SC_INTERNAL_SEPA;
		$s .= ( isset( $this->next_command ) ? $this->next_command : "?" );
		return $s;
	}

	function ProcessPage()
	{
		switch( $this->status )
		{
		case SC_EXIT:
			break;

		case SC_OK:
			$this->OutputPage( $this->path_template );
			break;

		case SC_ERR_CRITICAL_ERROR:
			$this->OutputCriticalErrorPage( $this->critical_err_msg );
			break;

		case SC_ERR_PAGE_NOT_FOUND:
			$msg = "Страната не е пронајдена ( " . $this->GetNextSc() . " )";
			$this->OutputCriticalErrorPage( $msg );
			break;

		case SC_ERR_WRONG_PAGE_SEQ:
			$msg = "Погрешна секвенца";
			$this->OutputCriticalErrorPage( $msg );
			break;

		case SC_ERR_UNAUTHORIZED:
			$msg = "Опа Хакер а !";
			$this->OutputCriticalErrorPage( $msg );
			break;

		case SC_ERR_CIRCULATION_SEQ:
			$s = "Страна на Секвенца : ";
			$s .= "PageSet = " . $this->ps_name . ", ";
			$s .= "Command = " . $this->cmd . "";
			$this->sys->SystemError( get_class($this) . '/ProcessPage', $s );
			break;

			default:
			$s = "Грешка во процесирањето : " . $this->status;
			$this->sys->SystemError( get_class($this) . '/ProcessPage', $s );
			break;
		}

		if ( DEBUG_WRITE_TO_CONSOLE )
		{
			CConsole::Write( get_class($this) . "/log", $this->PrintHistory() );
		}
	}

	function PrintHistory()
	{
		$s = '';
		$s .= "<table border='1' cellspacing='0' cellpadding='4'>";
		$s .= "<tr>";
		$s .= "<td style='color:white;background-color:#000080;'>&nbsp;</td>";
		$s .= "<td style='color:white;background-color:#000080;'>pageset</td>";
		$s .= "<td style='color:white;background-color:#000080;'>command</td>";
		$s .= "</tr>";
		$idx = 1;
		foreach( $this->history as $v )
		{
			$s .= "<tr>";
			$s .= "<td style='color:white;background-color:#000080;'>[" . $idx . "]</td>";
			$s .= "<td>" . $v['ps_name'] . "</td>";
			$s .= "<td>" . $v['cmd'] . "</td>";
			$s .= "</tr>";
			$idx++;
		}
		$s .= "</table>";

		return $s;
	}
}

?>