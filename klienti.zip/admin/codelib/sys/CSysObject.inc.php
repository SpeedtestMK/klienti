<?php
class CDatabase extends CMySQL
{
    
}

?>