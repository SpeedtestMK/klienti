<?php

class CVSystem extends CObject
{
	function &SetupSystem( $attri = null )
	{
		if ( $attri == null )
		{
			$attri = array(
				XA_CLASS=>'CVSystem'
			);
		}

		$null_ptr = null;
		$sys =& CObject::SetupObject( $null_ptr, 'sys', $attri );

		global $LANG_CODE;
		$sys->SetLangCode( $LANG_CODE );
		$sys->SetUserType( UT_GUEST );

		return $sys;
	}

	function &RunSystem( $attri )
	{
		$sys =& CObject::SetupSystem( $attri );
		$sys->Run();
		return $sys;
	}

	function Init( &$prt, $name = null, $attri = null )
	{
		parent::Init( $prt, $name, $attri );

		global $sys;
		$sys =& $this;
		$this->sys =& $this;

		global $LANG_CODE;
		$this->SetLangCode( $LANG_CODE );
	}
	
	function CreateChildren()
	{
		$this->OnCompoSpec( $compo );

		foreach ( $compo as $key => $val )
		{
			if ( $val != null )
			{
				$compo[$key] =& $this->CreateObject( $compo[$key] );
				eval( "\$this->" . $key . " =& \$compo['" . $key . "'];" );
				$compo[$key]->Init( $this );
			}
		}

		$this->OnLoadPageListSpec();
	}

	function OnCompoSpec( &$compo )
	{
		$compo = array(
			'Error'=>'CError',
			'Session'=>'CSession',
			'Authorization'=>'CAuthorization',
			'AuthSession'=>'CAuthSession',
			'PageSig'=>'CPageSig',
			'ZBuffer'=>'CZBuffer',
			'HtmlMacro'=>'CHtmlMacro',
			'Request'=>'CRequest',
			'State'=>'CState',
			'DB'=>'CDatabase',
			'SysInfo'=>'CSysInfo');
	}

	function OnLoadPageListSpec()
	{

	}

	function SetPageSetSpec( $spec )
	{
		$this->spec_pageset = $spec;
	}


	function GetIV( $key )
	{
		$v = $this->Request->Get( $key );
		if ( $v == null ) $v = ""; 
		return $v;
	}

	function SetIV( $key, $val )
	{
		$this->Request->Set( $key, $val );
	}

	function GetLangCode()
	{
		return $this->lang_code;
	}

	function SetLangCode( $lang_code )
	{
		$this->lang_code = $lang_code;
	}

	function GetUserType()
	{
		return $this->user_type;
	}

	function GetUserTypeCaption()
	{
		return constant( 'RSTR_UT_CAP_' . $this->GetUserType() );
	}

	function SetUserType( $user_type )
	{
		$this->user_type = $user_type;
	}

	function Run()
	{
		$this->ZBuffer->SetCallBack( 'page:state', $this );

		$sc =& new CSysCmd( $this );

		while ( $sc->GetNextPageSet( $ps ) )
		{
			if ( !isset( $this->spec_pageset[$ps] ) ) 
			{
				$sc->RaiseError( SC_ERR_PAGE_NOT_FOUND );
			}
			else
			{
				$this->PageSet =& $this->SetupObject( $this, $ps, $this->spec_pageset[$ps] );
				$this->PageSet->Run( $sc );
			}
		}

		$sc->ProcessPage();
		if ( DEBUG_WRITE_TO_CONSOLE )
		{
			CConsole::Write( get_class($this) . "/state", $this->State->PrintAll() );
		}
	}

	function GetPageSet()
	{
		return $this->PageSet;
	}

	function state()
	{
		return $this->sys->State->GetStateTag();
	}
}

?>