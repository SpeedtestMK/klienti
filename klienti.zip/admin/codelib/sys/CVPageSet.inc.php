<?php

class CVPageSet extends CObject
{
	function CreateChildren()
	{
		$this->OnLoadFieldListSpec();
	}
	function OnLoadFieldListSpec()
	{
		//[e.g.] include( 'df.fieldsets.inc.php' );
		//[e.g.] $this->SetFieldListSpec( $spec );
	}
	function SetFieldListSpec( $spec )
	{
		$this->spec_fieldsets = $spec;
	}
	function GetFieldListAttri( $name )
	{
		if ( !isset( $this->spec_fieldsets[$name] ) )
		{
			$this->sys->SystemError( get_class($this) . '/' . __METHOD__, "Полето ({$name}) не е цпецијализирано за : = " . $this->GetName() );
		}
		$attri = $this->spec_fieldsets[$name];
		if ( isset( $attri[XA_BASE] ) )
		{
			$base = $this->spec_fieldsets[$attri[XA_BASE]];
			foreach ( $attri as $key => $val )
				$base[$key] = $val;
			$attri = $base;
		}
		return $attri;
	}
	function &GetFieldList( $class_name, $obj_name = null )
	{
		if ( $obj_name == null ) $obj_name = $class_name;
		if ( isset( $this->clist[$obj_name] ) )
			return $this->clist[$obj_name];
		else
		{
			$attri = $this->GetFieldListAttri($class_name);
			$obj =& CObject::SetupObject( $this, $obj_name, $attri );
			return $obj;
		}
	}
	function SetPage( &$sc, $path, $page_id = "" )
	{
		if ( substr( $path, 0 , 1 ) == "=" )
		{
			$s = substr( $path, 1 );
		}
		else
		{
			if ( MULTI_LANG_TEMPLATE )
			{
				$s = "tpl." . $this->sys->GetLangCode() . "." . 
					$this->name . "." . $path . ".inc.php";
			}
			else
			{
				$s = "tpl." . $this->name . "." . $path . ".inc.php";
			}
		}
		$sc->SetPage( $s, $page_id );
	}
	function SetDisplay( $ns, $b )
	{
		$this->sys->ZBuffer->Set( $ns . "display", $b );
	}
	function ReportInfo( $s )
	{
		$this->sys->SysInfo->SetInfoMsg( $s );
	}
	function ReportError( $s )
	{
		$this->sys->SysInfo->SetErrMsg( $s );
	}
	function IsAuthorized()
	{
		if ( $this->sys->Get(XA_AUTH) === true )
		{
			if (( $this->Get(XA_AUTH) === true ) || ( $this->Get(XA_AUTH) === '' ))
				return $this->sys->AuthSession->Check();
			else
				return true;
		}
		else
		{
			if ( $this->Get(XA_AUTH) === true )
				return $this->sys->AuthSession->Check();
			else
				return true;
		}
	}
	function CommandProc( &$sc )
	{
		echo "Default CommandProc";
	}
	function Run( &$sc )
	{
		if ( !$this->IsAuthorized() )
		{
			$sc->SetNextSc( '/' );
			return;
		}
		while ( $sc->GetNextCommand( $this ) )
		{
			if ( isset( $this->sys->Authorization ) )
			{
				if ( !$this->sys->Authorization->IsAuthorized( $sc->Ps(), $sc->Cmd() ) )
				{
					$sc->RaiseError( SC_ERR_UNAUTHORIZED );
					return;
				}
			}
			$this->CommandProc( $sc );
		}
	}
}

?>