<?php

class CAuthorization extends CObject
{
	function IsAuthorized( $ps, $cmd )
	{
		return true;
	}
}

?>