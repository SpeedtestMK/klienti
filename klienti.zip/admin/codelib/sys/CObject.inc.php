<?php

class CObject
{
	var $sys; // Систем
	var $prt; // Параметар
	var $name; // Име
	var $clist; // Листа

	function Init( &$prt, $name = null, $attri = null ) 
	{
		if ( is_null( $prt ) )
		{
			$this->prt = null;
			$this->sys = null;
		}
		else
		{
			$this->prt =& $prt;
			if ( !is_null( $prt->sys ) ) $this->sys =& $prt->sys;

			if ( $name == null )
				$this->prt->clist[] =& $this;
			else
				$this->prt->clist[$name] =& $this;
		}
		
		$this->name = $name;
		$this->attri = $attri;
		$this->clist = array();
	}

	function Get( $key )
	{
		if ( isset( $this->attri[$key] ) )
			return $this->attri[$key];
		else
			return '';
	}

	function Set( $key, $val )
	{
		$this->attri[$key] = $val;
		return $val;
	}

	function Create()
	{
		$this->CreateChildren();
		foreach( $this->clist as $name => $obj )
			$this->clist[$name]->Create();
	}

	function CreateChildren()
	{
	}

	function ConstructObjects( $spec )
	{
		foreach( $spec as $name => $attri )
			$this->ConstructObject( $name, $attri );
	}
	
	function &ConstructObject( $name, $attri )
	{
 		$obj =& $this->CreateObject( $attri[XA_CLASS] );
		$obj->Init( $this, $name, $attri );
		return $obj;
	}

	function Setup()
	{
		foreach( $this->clist as $key => $obj ) $this->clist[$key]->Setup();
	}

	function &GetChild( $name )
	{
		return $this->clist[$name];
	}

	function GetChildList()
	{
		return $this->clist;
	}

	function GetName()
	{
		return $this->name;
	}
	
	function &CreateObject( $class_name )
	{
		if ( !class_exists( $class_name ) )
		{
			CObject::SystemError( get_class($this) . '/' . __METHOD__, "Class ({$class_name}) does not exist." );
		}
		
		$p = null;
		eval( "\$p =& new " . $class_name . ";" );
		return $p;
	}

	function &InitObject( &$prt, $name, $attri )
	{
		$obj =& CObject::CreateObject( $attri[XA_CLASS] );
		$obj->Init( $prt, $name, $attri );
		return $obj;
	}

	function &SetupObject( &$prt, $name, $attri )
	{
		$obj =& CObject::InitObject( $prt, $name, $attri );
		$obj->Create();
		$obj->Setup();
		return $obj;
	}

	function &RunObject( &$prt, $name, $attri )
	{
		$obj =& CObject::SetupObject( $prt, $name, $attri );
		$obj->Run();
		return $obj;
	}

	function SystemError( $loc, $msg )
	{
		$s = "";
		$s .= "<hr>";
		$s .= "<font color='#40404'>Location : </font><font color='#FF0000'><b>" . $loc . "</b></font><br>";
		$s .= "<font color='#40404'>Message  : </font><font color='#FF0000'><b>" . $msg . "</b></font><br>";
		$s .= "<hr>";
		if ( DEBUG_WRITE_TO_CONSOLE )
		{
			CConsole::Write( get_class($this) . '/system_error', $s );
		}
		echo $s;
		exit;
	}

	function PrintTree()
	{
		echo "<div align='left'>";
		echo "<table border='1' cellspacing='0' cellpadding='10' bgcolor='#FFFFF0'>";
		echo "<tr><td align='left'><pre>\r\n" . $this->PrintTreeX() . "</pre></td></tr></table>";
		echo "</div>";
	}

	function PrintTreeX( $indent = '' )
	{
		$s = $indent . get_class($this) . "\r\n";
		foreach ( $this->clist as $key => $val )
			$s .= $val->PrintTreeX( $indent . "\t" );
		return $s;
	}
}	

?>