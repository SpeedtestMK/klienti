<?php

class CVMsg
{
	var $sender;
	var $ls;
	var $msg_arr;

	function Init( $sender, &$ls, &$msg_arr )
	{
		$this->sender = $sender;
		$this->ls =& $ls;
		$this->msg_arr =& $msg_arr;
	}

	function Get( $key )
	{
		if ( isset( $this->msg_arr[$key] ) )
			return $this->msg_arr[$key];
		else
			return '';
	}

	function Set( $key, $val )
	{
		$this->msg_arr[$key] = $val;
		return $val;
	}
}

?>