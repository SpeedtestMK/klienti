<?php

define( 'PATH_CONFIG', dirname(__FILE__) . '/' );
require( dirname( dirname(__FILE__) ) . '/codelib/cfg/config.global.inc.php' );
require( 'config.db.inc.php' );

?>