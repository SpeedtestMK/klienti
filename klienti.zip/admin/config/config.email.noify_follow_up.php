//<?php exit; ?>
//---------------------------------------------------------------
//---------------------------------------------------------------
//---------------------------------------------------------------
//---------------------------------------------------------------
//
// Конфигурација на емаил
//
//---------------------------------------------------------------
//---------------------------------------------------------------
//---------------------------------------------------------------
//---------------------------------------------------------------

//---------------------------------------------------------------
// Hostname 
//---------------------------------------------------------------
//
// The address of SMTP server
//
// ( example1 ) Hostname=localhost
// ( example2 ) Hostname=mail.mydomain.com
// ( example3 ) Hostname=111.222.333.444
//

Hostname=localhost

//---------------------------------------------------------------
// SMTP Authentication
//---------------------------------------------------------------
//
// If your email server requires SMTP Authentication,
// enable the following three lines, "Auth", "Username", and
// "Password"
// ( NOTE: They are commented out by default. )
//
// Set "LOGIN", your SMTP username, and password to
// "Auth", "Username", and "Password" respectively.
//

Auth=LOGIN
Username=klienti@kanal77.com.mk
Password=7qvt6t2738mocko007�123

//---------------------------------------------------------------
// From
//---------------------------------------------------------------
//
// The sender of the form mail
//
// ( example1 ) From=sender@mydomain.com
// ( example2 ) From=John Smith <john@smith.com>
//

From=klineti@kanal77.com.mk

//---------------------------------------------------------------
// Cc
//---------------------------------------------------------------
//
// Carbon Copy (Cc)
//
// ( example1 ) Cc=john@smith.com
// ( example2 ) Cc=John Smith <john@smith.com>
// ( example3 ) Cc=john@smith.com | nancy@gold.com
// ( example4 ) Cc=John Smith <john@smith.com> | Nancy Gold <nancy@gold.com>
//

Cc=

//---------------------------------------------------------------
// Bcc
//---------------------------------------------------------------
//
// Blind Carbon Copy (Bcc)
//
// ( example1 ) Bcc=john@smith.com
// ( example2 ) Bcc=John Smith <john@smith.com>
// ( example3 ) Bcc=john@smith.com | nancy@gold.com
// ( example4 ) Bcc=John Smith <john@smith.com> | Nancy Gold <nancy@gold.com>
//

Bcc=

//---------------------------------------------------------------
// Email Subject
//---------------------------------------------------------------
//
// (e.g.) "Contact Us"
//

Subject=Follow-Up Notification

//---------------------------------------------------------------
// Email Body Template ( Text Format )
//---------------------------------------------------------------

Body=<<<_EOM_
Created On : ##rlog_create_date_time##
Company Name : ##company_name##
Business Type : ##business_type##
Market Segment : ##market_segment##
Contact : ##contact##
Follow Up : ##follow_up##
Title : ##title##
Street1 : ##street1##
Street2 : ##street2##
City : ##city##
State : ##state##
Zip : ##zip##
Country : ##country##
Office Tel : ##office_tel##
Cell Phone : ##cell_phone##
Fax : ##fax##
Email : ##email##
Web Site : ##website##
Comment : ##comment##
_EOM_

//---------------------------------------------------------------
// Email Body Template ( HTML Format )
//---------------------------------------------------------------

Html=<<<_EOM_
<html>
<head>
	<title>Follow-Up Notification</title>
</head>
<body>
	<table>
		<tr><td align='right'>Created On : </td><td align='left'>##rlog_create_date_time##</td></tr>
		<tr><td align='right'>Company Name : </td><td align='left'>##company_name##</td></tr>
		<tr><td align='right'>Business Type : </td><td align='left'>##business_type##</td></tr>
		<tr><td align='right'>Market Segment : </td><td align='left'>##market_segment##</td></tr>
		<tr><td align='right'>Contact : </td><td align='left'>##contact##</td></tr>
		<tr><td align='right'>Follow Up : </td><td align='left'>##follow_up##</td></tr>
		<tr><td align='right'>Title : </td><td align='left'>##title##</td></tr>
		<tr><td align='right'>Street1 : </td><td align='left'>##street1##</td></tr>
		<tr><td align='right'>Street2 : </td><td align='left'>##street2##</td></tr>
		<tr><td align='right'>City : </td><td align='left'>##city##</td></tr>
		<tr><td align='right'>State : </td><td align='left'>##state##</td></tr>
		<tr><td align='right'>Zip : </td><td align='left'>##zip##</td></tr>
		<tr><td align='right'>Country : </td><td align='left'>##country##</td></tr>
		<tr><td align='right'>Office Tel : </td><td align='left'>##office_tel##</td></tr>
		<tr><td align='right'>Cell Phone : </td><td align='left'>##cell_phone##</td></tr>
		<tr><td align='right'>Fax : </td><td align='left'>##fax##</td></tr>
		<tr><td align='right'>Email : </td><td align='left'>##email##</td></tr>
		<tr><td align='right'>Web Site : </td><td align='left'>##website##</td></tr>
		<tr><td align='right'>Comment : </td><td align='left'>##comment##</td></tr>
	</table>
</body>
</html>
_EOM_

//---------------------------------------------------------------
// END OF FILE
//---------------------------------------------------------------
