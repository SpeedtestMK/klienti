<html>
    <head>
        <title>Маркетинг резултати</title>
    </head>
<body>
    <h1>Маркетинг клиент - Снежана Мицевска</h1>
<?php
header('Content-Type: text/html; charset=utf-8');
$servername = "localhost"; // името на серверот
$username = "root"; // корисничко име на базата
$password = ""; // лозинка на базата
$dbname = "klienti"; // име на базата

// креирање конекција
$conn = new mysqli($servername, $username, $password, $dbname);
// проверка
if ($conn->connect_error) {
    die("Грешка: " . $conn->connect_error);
}
mysqli_set_charset($conn,"utf8");
$sql = "SELECT lead_id, company_name, vreme, rlog_edit_date_time, comment FROM tbl_lead WHERE rlog_create_user_id=1009";
$rezultati = $conn->query($sql);

if ($rezultati->num_rows > 0) {
    // излез
    while($row = $rezultati->fetch_assoc()) {
        echo "ID Број: " . $row["lead_id"]. "<br/>Име на компанијата: <strong>" . $row["company_name"]. "</strong><br/> Уште колку време преостанува - " . $row["vreme"].  "<br>Последна внесена забелешка на - <strong>" .$row["rlog_edit_date_time"]. "</strong><br>===================================================<br> Внесени забелешки<br>" . $row["comment"] . "<br>===================================================<br><br><br><br>";
        //echo "ID Број: " . mb_detect_encoding($row["lead_id"]). " - Име на компанијата: " . mb_detect_encoding($row["company_name"]). "<br>";;
    }
} else {
    echo "0 резултати - имаш грешка";
}
$conn->close();
?> 
</body>
</html>