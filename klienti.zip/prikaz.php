<html>
    <head>
        <title>Маркетинг резултати</title>
    </head>
<body>
    <h1>Маркетинг клиент - Снежана Мицевска</h1>
<?php
header('Content-Type: text/html; charset=utf-8');
$servername = "localhost"; // името на серверот
$username = "root"; // корисничко име на базата
$password = ""; // лозинка на базата
$dbname = "klienti"; // име на базата

// креирање конекција
$conn = new mysqli($servername, $username, $password, $dbname);
// проверка
if ($conn->connect_error) {
    die("Грешка: " . $conn->connect_error);
}
mysqli_set_charset($conn,"utf8");
$sql = "SELECT lead_id, company_name, vreme FROM tbl_lead WHERE rlog_create_user_id=1009";
$rezultati = $conn->query($sql);

if ($rezultati->num_rows > 0) {
    // излез
    while($row = $rezultati->fetch_assoc()) {
        echo "ID Број: " . $row["lead_id"]. "<br/>Име на компанијата: " . $row["company_name"]. "<br/> Колку време преостанува - " . $row["vreme"]. "<br>===================================================<br>";
        //echo "ID Број: " . mb_detect_encoding($row["lead_id"]). " - Име на компанијата: " . mb_detect_encoding($row["company_name"]). "<br>";;
    }
} else {
    echo "0 резултати - имаш грешка";
}
$conn->close();
?> 
</body>
</html>